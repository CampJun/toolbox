mod input;
mod platform;
mod render;
mod world;

use sdl2::event::Event;
use sdl2::pixels::Color;

use input::{Action, Input};
use render::{draw_glyph, load_atlas, CELL_SIZE};
use world::{Tile, World};

const WORLD_W: u32 = 40;
const WORLD_H: u32 = 30;
const ATLAS_PNG: &[u8] = include_bytes!("../assets/cp437_16x16.png");

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let sdl = sdl2::init()?;
    let video = sdl.video()?;

    let logical_w = WORLD_W * CELL_SIZE;
    let logical_h = WORLD_H * CELL_SIZE;

    let window = video
        .window("Holy Land — hello world", logical_w, logical_h)
        .position_centered()
        .resizable()
        .build()?;

    let mut canvas = window
        .into_canvas()
        .accelerated()
        .present_vsync()
        .build()?;
    canvas.set_logical_size(logical_w, logical_h)?;

    let texture_creator = canvas.texture_creator();
    let mut atlas = load_atlas(&texture_creator, ATLAS_PNG)?;

    let mut events = sdl.event_pump()?;
    let mut input = Input::new();
    let mut world = World::new(WORLD_W, WORLD_H);
    let palette = Palette::default();

    'main: loop {
        for event in events.poll_iter() {
            match event {
                Event::Quit { .. } => break 'main,
                _ => input.handle_sdl_event(&event),
            }
        }
        input.poll_gamepad();

        for action in input.drain() {
            match action {
                Action::Up => world.try_move(0, -1),
                Action::Down => world.try_move(0, 1),
                Action::Left => world.try_move(-1, 0),
                Action::Right => world.try_move(1, 0),
                Action::Start => break 'main,
                _ => {}
            }
        }

        canvas.set_draw_color(palette.letterbox);
        canvas.clear();

        for y in 0..world.height as i32 {
            for x in 0..world.width as i32 {
                let (g, fg, bg) = match world.tile(x, y) {
                    Tile::Floor => (b'.', palette.floor_fg, palette.floor_bg),
                    Tile::Wall => (b'#', palette.wall_fg, palette.wall_bg),
                };
                draw_glyph(&mut canvas, &mut atlas, x, y, g, fg, bg);
            }
        }
        draw_glyph(
            &mut canvas,
            &mut atlas,
            world.player.0,
            world.player.1,
            b'@',
            palette.player_fg,
            palette.floor_bg,
        );

        canvas.present();
    }

    Ok(())
}

struct Palette {
    letterbox: Color,
    player_fg: Color,
    floor_fg: Color,
    floor_bg: Color,
    wall_fg: Color,
    wall_bg: Color,
}

impl Default for Palette {
    fn default() -> Self {
        Self {
            letterbox: Color::RGB(8, 6, 4),
            player_fg: Color::RGB(240, 232, 200),
            floor_fg: Color::RGB(70, 60, 45),
            floor_bg: Color::RGB(20, 17, 13),
            wall_fg: Color::RGB(140, 110, 75),
            wall_bg: Color::RGB(35, 28, 20),
        }
    }
}
