#[derive(Clone, Copy, PartialEq, Eq)]
pub enum Tile {
    Floor,
    Wall,
}

pub struct World {
    pub width: u32,
    pub height: u32,
    pub tiles: Vec<Tile>,
    pub player: (i32, i32),
}

impl World {
    pub fn new(width: u32, height: u32) -> Self {
        let mut tiles = vec![Tile::Floor; (width * height) as usize];
        let w = width as i32;
        let h = height as i32;

        for x in 0..w {
            tiles[idx(width, x, 0)] = Tile::Wall;
            tiles[idx(width, x, h - 1)] = Tile::Wall;
        }
        for y in 0..h {
            tiles[idx(width, 0, y)] = Tile::Wall;
            tiles[idx(width, w - 1, y)] = Tile::Wall;
        }

        let mid_y = h / 2;
        for x in (w / 4)..(3 * w / 4) {
            if x % 4 != 0 {
                tiles[idx(width, x, mid_y)] = Tile::Wall;
            }
        }

        Self {
            width,
            height,
            tiles,
            player: (2, 2),
        }
    }

    pub fn tile(&self, x: i32, y: i32) -> Tile {
        if x < 0 || y < 0 || x >= self.width as i32 || y >= self.height as i32 {
            return Tile::Wall;
        }
        self.tiles[idx(self.width, x, y)]
    }

    pub fn try_move(&mut self, dx: i32, dy: i32) {
        let nx = self.player.0 + dx;
        let ny = self.player.1 + dy;
        if self.tile(nx, ny) == Tile::Floor {
            self.player = (nx, ny);
        }
    }
}

fn idx(w: u32, x: i32, y: i32) -> usize {
    (y as u32 * w + x as u32) as usize
}
