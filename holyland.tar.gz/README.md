# Holy Land

Low-fantasy biblical sim/roguelike. CP437 rendering, gamepad-first, cross-platform from desktop to retro handhelds.

See `/root/.claude/plans/yes-but-before-deciding-keen-stonebraker.md` for the full design plan.

## Status

**Session 1 / Half 1 — desktop hello-world.** A `@` walks around a CP437 grid; `#` blocks; `.` is floor; Start (or Esc / Enter) quits. Procedural placeholder glyphs only — real CP437 atlas comes later.

## Build (desktop)

SDL2 is bundled and statically linked via the `sdl2` crate's `bundled` + `static-link` features, so no system SDL2 install is required. First build is slow (compiles SDL2 from source); subsequent builds are fast.

```
cargo run --release
```

Requires: Rust toolchain, a C compiler (cc/gcc), `cmake`, `make`.

## Controls

Tier 1 (floor — every device, including SNES-class handhelds):

| Action      | Keyboard                         | Gamepad        |
|-------------|----------------------------------|----------------|
| Move        | Arrow keys / WASD / HJKL         | Dpad           |
| A / B / X / Y | Z / X / C / V                  | Face buttons   |
| L / R       | Q / E                            | Shoulder buttons |
| Start       | Enter / Esc                      | Start          |
| Select      | Backspace / Right Shift          | Select         |

Tier 2 (analog sticks → action wheels) is reserved for Session 3+; see plan.

## Project layout

```
holyland/
├── Cargo.toml              bundled+static SDL2 + gilrs
├── .cargo/config.toml      cross-compile target stubs
├── assets/                 (real CP437 PNG atlas lands here later)
└── src/
    ├── main.rs             SDL init + event loop + letterboxed render
    ├── render.rs           draw_glyph(x, y, glyph, fg, bg) — the only drawing API
    ├── input.rs            Action enum + gilrs/keyboard + repeat-on-hold
    ├── world.rs            placeholder tilemap + player (replaced when ECS lands)
    └── platform/           OS-specific code lives here, nowhere else
        ├── mod.rs
        ├── desktop.rs      XDG paths, fallback to exe-adjacent saves
        ├── linux_handheld.rs  reserved for Miyoo/MinUI specifics
        └── android.rs      stub for Retroid (Session 2)
```

## Cross-compile (Session 1 / Half 2 — Miyoo Mini Plus)

Not yet attempted; planned next. Target triple `armv7-unknown-linux-musleabihf`. Will require a musl ARM cross toolchain and a statically-buildable SDL2. See plan for budget and bail-out criteria.

## Cross-compile (Session 2 — Retroid Pocket 5)

Target triple `aarch64-linux-android`. Will use `cargo-ndk` + `cargo-apk`. Application code unchanged; `src/platform/android.rs` becomes live.

## What's deliberately not here yet

ECS, save/load, audio, NPCs, harvesting, combat, blessings, demons, oasis/wilderness loops, action wheels, tile-mode sprites, real CP437 font atlas. All deferred per plan.
